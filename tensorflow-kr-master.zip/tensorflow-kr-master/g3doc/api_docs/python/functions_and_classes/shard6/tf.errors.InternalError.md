Raised when the system experiences an internal error.

This exception is raised when some invariant expected by the runtime
has been broken. Catching this exception is not recommended.

- - -

#### `tf.errors.InternalError.__init__(node_def, op, message)` {#InternalError.__init__}

Creates an `InternalError`.


