### `tf.test.get_temp_dir()` {#get_temp_dir}

Returns a temporary directory for use during tests.

There is no need to delete the directory after the test.

##### Returns:

  The temporary directory.

