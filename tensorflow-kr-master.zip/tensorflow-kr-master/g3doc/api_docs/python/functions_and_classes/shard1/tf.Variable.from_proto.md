#### `tf.Variable.from_proto(variable_def)` {#Variable.from_proto}

Returns a `Variable` object created from `variable_def`.

