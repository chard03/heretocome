### `tf.get_variable_scope()` {#get_variable_scope}

Returns the current variable scope.

