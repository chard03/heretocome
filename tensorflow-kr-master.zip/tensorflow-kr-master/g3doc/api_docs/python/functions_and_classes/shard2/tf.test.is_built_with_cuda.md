### `tf.test.is_built_with_cuda()` {#is_built_with_cuda}

Returns whether TensorFlow was built with CUDA (GPU) support.

