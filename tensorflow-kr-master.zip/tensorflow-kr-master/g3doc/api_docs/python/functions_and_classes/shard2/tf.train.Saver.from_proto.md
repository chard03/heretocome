#### `tf.train.Saver.from_proto(saver_def)` {#Saver.from_proto}

Returns a `Saver` object created from `saver_def`.

