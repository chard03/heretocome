### `tf.logical_xor(x, y, name='LogicalXor')` {#logical_xor}

x ^ y = (x | y) & ~(x & y).

