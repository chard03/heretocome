### `tf.contrib.framework.add_model_variable(var)` {#add_model_variable}

Adds a variable to the MODEL_VARIABLES collection.

##### Args:


*  <b>`var`</b>: a variable.

