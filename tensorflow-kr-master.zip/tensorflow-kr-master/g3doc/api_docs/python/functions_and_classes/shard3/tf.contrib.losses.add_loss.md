### `tf.contrib.losses.add_loss(loss)` {#add_loss}

Adds a externally defined loss to collection of losses.

##### Args:


*  <b>`loss`</b>: A loss `Tensor`.

