The request does not have valid authentication credentials.

This exception is not currently used.

- - -

#### `tf.errors.UnauthenticatedError.__init__(node_def, op, message)` {#UnauthenticatedError.__init__}

Creates an `UnauthenticatedError`.


