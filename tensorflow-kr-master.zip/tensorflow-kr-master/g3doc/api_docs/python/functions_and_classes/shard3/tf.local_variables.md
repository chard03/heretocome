### `tf.local_variables()` {#local_variables}

Returns all variables created with collection=[LOCAL_VARIABLES].

##### Returns:

  A list of local Variable objects.

