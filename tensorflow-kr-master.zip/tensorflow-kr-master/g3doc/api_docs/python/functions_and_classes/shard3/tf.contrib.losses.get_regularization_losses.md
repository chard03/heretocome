### `tf.contrib.losses.get_regularization_losses(scope=None)` {#get_regularization_losses}

Gets the regularization losses.

##### Args:


*  <b>`scope`</b>: an optional scope for filtering the losses to return.

##### Returns:

  A list of loss variables.

