Raised when the runtime is currently unavailable.

This exception is not currently used.

- - -

#### `tf.errors.UnavailableError.__init__(node_def, op, message)` {#UnavailableError.__init__}

Creates an `UnavailableError`.


