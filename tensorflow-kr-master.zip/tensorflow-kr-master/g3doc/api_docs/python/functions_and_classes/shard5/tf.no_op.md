### `tf.no_op(name=None)` {#no_op}

Does nothing. Only useful as a placeholder for control edges.

##### Args:


*  <b>`name`</b>: A name for the operation (optional).

##### Returns:

  The created Operation.

