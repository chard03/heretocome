str(object='') -> string

Return a nice string representation of the object.
If the argument is a string, the return value is the same object.
