### `tf.test.main()` {#main}

Runs all unit tests.

