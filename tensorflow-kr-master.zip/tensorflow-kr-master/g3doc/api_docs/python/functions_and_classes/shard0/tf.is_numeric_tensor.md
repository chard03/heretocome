### `tf.is_numeric_tensor(tensor)` {#is_numeric_tensor}



