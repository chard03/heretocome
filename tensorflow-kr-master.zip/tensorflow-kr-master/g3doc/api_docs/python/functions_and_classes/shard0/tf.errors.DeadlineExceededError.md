Raised when a deadline expires before an operation could complete.

This exception is not currently used.

- - -

#### `tf.errors.DeadlineExceededError.__init__(node_def, op, message)` {#DeadlineExceededError.__init__}

Creates a `DeadlineExceededError`.


