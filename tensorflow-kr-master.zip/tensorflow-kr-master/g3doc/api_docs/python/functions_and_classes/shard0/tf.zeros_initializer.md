### `tf.zeros_initializer(shape, dtype=tf.float32)` {#zeros_initializer}

An adaptor for zeros() to match the Initializer spec.

