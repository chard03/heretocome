### `tf.contrib.losses.get_losses(scope=None)` {#get_losses}

Gets the list of loss variables.

##### Args:


*  <b>`scope`</b>: an optional scope for filtering the losses to return.

##### Returns:

  a list of loss variables.

