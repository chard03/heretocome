# `struct tensorflow::TensorShapeDim`





###Member Details

#### `int64 tensorflow::TensorShapeDim::size` {#int64_tensorflow_TensorShapeDim_size}





#### `tensorflow::TensorShapeDim::TensorShapeDim(int64 s)` {#tensorflow_TensorShapeDim_TensorShapeDim}




