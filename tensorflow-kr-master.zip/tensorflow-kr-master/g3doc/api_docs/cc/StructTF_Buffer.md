# `struct TF_Buffer`





###Member Details

#### `const void* TF_Buffer::data` {#const_void_TF_Buffer_data}





#### `size_t TF_Buffer::length` {#size_t_TF_Buffer_length}





#### `void(* TF_Buffer::data_deallocator) (void *data, size_t length))(void *data, size_t length)` {#void_TF_Buffer_data_deallocator_void_data_size_t_length_}




