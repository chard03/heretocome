# `class tensorflow::Thread`





###Member Details

#### `tensorflow::Thread::Thread()` {#tensorflow_Thread_Thread}





#### `tensorflow::Thread::~Thread()` {#tensorflow_Thread_Thread}

Blocks until the thread of control stops running.


