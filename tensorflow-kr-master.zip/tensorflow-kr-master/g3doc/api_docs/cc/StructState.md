# `struct tensorflow::Status::State`





###Member Details

#### `tensorflow::error::Code tensorflow::Status::State::code` {#tensorflow_error_Code_tensorflow_Status_State_code}





#### `string tensorflow::Status::State::msg` {#string_tensorflow_Status_State_msg}




